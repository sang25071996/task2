$(document).ready(function(){
    $('.bazzaar').parallax();
});