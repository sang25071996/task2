$(document).ready(function () {
    $('.h').click(function () {
        $('#menu2').hide();
        $('#home').show();
    });
    $('.m').click(function () {
        $('#home').hide();
        $('#menu2').show();
    });
});