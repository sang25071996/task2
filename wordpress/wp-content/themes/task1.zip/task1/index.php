<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="UTF-8">
    <title>test</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" type="text/css" href="css/slick-theme.css">
    <link rel="stylesheet" type="text/css" href="css/slick.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/lightbox.css">
    <!-- <link rel="stylesheet" type="text/css" href="font-awesome-4.7.0"> -->

    <!--<script src="js/bootstrap.min.js"></script>-->
    <!--<script src="slick/js/slick.js"></script>-->
</head>
<body data-spy="scroll" data-target=".navbar-example" >
<div class="wrapper">
    <div id="header">
        <div class="top">
            <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation" id="navbar-example">
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar" style="color: #fff"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" style="color: #00a8ff">The Curseborn Saga</a>
                    </div>
                    <div class="collapse navbar-collapse navbar-right">
                        <ul class="nav navbar-nav">
                            <li id="ho"><a href="#header" class="">HOME</a></li>
                            <li id="in"><a href="#content" class="">INFO</a></li>
                            <li id="ch"><a href="#book" class="">THE BOOKS SERIES</a></li>
                            <li id="th"><a href="#creww" class="">THE CREW</a></li>
                            <li id="se"><a href="#see" class="">SEE OUR WORLD</a></li>
                            <li id="ba"><a href="#baza" class="">BAZAAR</a></li>
                            <li id="co"><a href="#ct" class="">CONTACT</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
            <div class="center">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 col-xs-12">
                            <div class="center-header">
                                <span>NIGHT AND DAY</span>
                                <p>After the moment known as EIEN unfolded, and the birth of Universe came to be, a Goddess awakened upon a floating rock in a world filled with beauty and endless possibility. Upon awakening, she learned her name, and from that moment on, all that lived in the universe knew Life as Lady Vale. Yet, she ...</p>
                            </div>
                        </div>
                        <div class="col-md-12 col-xs-12">
                            <!--<section id="section02" class="demo">-->
                                <!--<div class="st">-->
                                    <!--<a href="#section03"><div class="stt" ><span class="section" style="margin-top: 150px"></span></div></a>-->
                                <!--</div>-->
                            <!--</section>-->
                            <div class="bottom item"><button class="circle"><a href="#section03"><i class="arrow fa fa-arrow-down" aria-hidden="true"></i></a></button></div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    <div id="content">
        <section id="section03">
            <div class="container">
                <div class="row">
                    <div class="content-header">
                        <div class="col-md-6 col-xs-12">
                            <div class="content-top">
                                <span class="content-span">What is the Curseborn Saga?</span>
                                <div class="content-p1">
                                    <p>The Novella Series {} The Curseborn Saga</p>
                                </div>
                                <p style="margin-top: 20px">The Curseborn Saga is a high fantasy epic, set in the distant fictional realm known as Soria. It tells the tale of Death’s unrelenting pursuit of Lady Life, and the never-ending war known as Ragnarok. The Curseborn Saga is a 22 Chapter Series that will be released one by one in the form of short novellas. Each novella will have it’s own unique cover drawn by the legend and master of artwork, Ji Se.</p>
                                <div class="content-button">
                                    <button class="button"><i class="fa fa-briefcase" aria-hidden="true"></i> READ MORE</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-xs-12">
                        <div class="content-img">
                            <div class="content-bg">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <div id="book" class="bg">
        <div class="container" style="width: 100%;">
            <div class="row">
                <div class="col-md-12 col-xs-12">
                    <div class="bg-item">
                        <span>THE CHARACTERS</span>
                    </div>
                </div>
            </div>
            <div class="item-1"></div>
            <div class="item-2"></div>
            <div class="row">
                <div class="item" id="slide" >
                    <div class="col-md-3 col-xs-12 col-sm-6">
                        <div class="image"></div>
                        <div class="info">
                            <span>STORM</span>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-xs-12 col-sm-6">
                        <div class="image-1"></div>
                        <div class="info">
                            <span>STORM</span>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-xs-12 col-sm-6">
                        <div class="image-2"></div>
                        <div class="info">
                            <span>STORM</span>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-xs-12 col-sm-6">
                        <div class="image"></div>
                        <div class="info">
                            <span>STORM</span>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-xs-12 col-sm-6">
                        <div class="image"></div>
                        <div class="info">
                            <span>STORM</span>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore</p>
                        </div>
                    </div>
                    <div class="col-md-3 col-xs-12 col-sm-6">
                        <div class="image"></div>
                        <div class="info">
                            <span>STORM</span>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="creww" class="crew">
        <div class="container">
            <div class="crew-header">
                <P>THE CREW</P>
            </div>
            <div class="item-1-crew"></div>
            <div class="item-2-crew"></div>
            <div class="crew-content">
                <p>We are the Four Lords. Two brothers and two best mates who have learned that our minds will always and forever work at their best when you work with others.</p>
                <p>We are story tellers in trade, and we long to create something that has never been before. Something that will touch people’s hearts and leave them breathless. We are just like you. We work normal jobs everyday, and try desperately to find our way in this labyrinth we have all come to know as life. But for us, even in the toughest of times, and we all have them, it was always stories that kept us going. It is our passion. It is how we can live life, yet still create. We believe that stories are the heart of everything.</p>
                <p>That’s exactly why four years ago, we came together from the corners of this world and began working on our own story. “One of the greatest stories ever told.” This is what we told ourselves we would create. We devote our lives to this. To give something back to the world after the artists of the past have already given so much. We would not be who we are without them. And in turn, are willing to stake our futures on creating something for others. We are artists. We may be irrational, reckless, and stupid at times . . . But we know how to love.</p>
                <p>THE FOUR LORDS</p>
                <p>Director – Marten D. Shanks {} Writer – Trowa D. Cloud Creator – Simon Gatsu Sandoval {}</p>
                <p>Creator – Peter Ace Kolias </p>
                <button class="crew-button"><i class="fa fa-briefcase" aria-hidden="true"></i> READ MORE</button>
            </div>
        </div>
    </div>
    <div  class="novella">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-xs-12">
                    <div class="nevolla-header">
                        <p>THE NOVELLAS</p>
                    </div>
                </div>
            </div>
            <div class="item-1"></div>
            <div class="item-2"></div>
            <div class="row">
                <div id="nove" class="nove-i">
                    <div class="col-md-3 col-xs-12 col-sm-6">
                        <div class="square"><p>ARC I: THE SOLDIER GAMES</p></div>
                    </div>
                    <div class="col-md-3 col-xs-12 col-sm-6">
                        <div class="square"><p>ARC II: DIVING DEEP, THE 100 RING FESTIVAL</p></div>
                    </div>
                    <div class="col-md-3 col-xs-12 col-sm-6">
                        <div class="square"><p>ARC III: LAW OF BLOOD</p></div>
                    </div>
                    <div class="col-md-3 col-xs-12 col-sm-6">
                        <div class="square"><p>ARC IV: THE DRAGON KING</p></div>
                    </div>
                    <div class="col-md-3 col-xs-12 col-sm-6">
                        <div class="square"><p>ARC II: DIVING DEEP, THE 100 RING FESTIVAL</p></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="see" class="seeworld">
        <div class="container">
            <div class="seeworld-header">
                SEE <b>OUR WORLD</b>
            </div>
            <div class="item-1-seeworld"></div>
            <div class="item-2"></div>
            <div class="seeworld-content">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum</p>
            </div>
        </div>
    </div>
    <div class="filter">
        <div class="container">
            <div class="row">
                <div class="filter-header">
                    <div class="col-md-8 col-xs-6">
                        <div class="filter-type">
                            <p>Filter by type</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-xs-6">
                    <div class="filter-character">
                        <div class="filter-menu">
                            <ul class="nav nav-tabs">
                                <li class="active"><a data-toggle="tab" href="#home" class="h">The Characters </a></li>
                                <li><a data-toggle="tab" href="#menu2" class="m">| Conceptual Artwork</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-content">
                <div class="filter-image">
                    <div class="row">
                    <div class="tab-pane fade in active" id="home">
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="filter_image-header"></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="type-image"></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="type-image-2"></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="type-image-3"></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="filter_image-header"></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="type-image"></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="type-image-2"></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="type-image-3"></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="filter_image-header"></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="type-image"></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="type-image-2"></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="type-image-3"></div>
                                        </a>
                                    </div>
                                </div>
                    </div>
                    <div class="tab-pane fade" id="menu2" style="display: none">
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="type-image-2"></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="type-image"></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="type-image-2"></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="type-image-3"></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="filter_image-header"></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="type-image"></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="type-image-2"></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="type-image-3"></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="filter_image-header"></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="type-image"></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="type-image-2"></div>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-md-4 col-sm-4 col-xs-6">
                                    <div class="thumbnail">
                                        <a href="./img/char3.png"style="width: 262.5px; height: 302.5px" data-lightbox="char3">
                                            <div class="type-image-3"></div>
                                        </a>
                                    </div>
                                </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="baza" class="bazzaar">
        <div class="bazzaar-header">
            <p>BAZAAR</p>
        </div>
        <div class="item-1"></div>
        <div class="item-2"></div>
        <div class="container">
            <div class="bazzaar-content">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum

                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum</p>
            </div>
        </div>
    </div>
    <div id="ct" class="contact">
        <div class="container">
            <div class="contact-header">
                <p>FELL FREE TO <b>CONTACT US</b></p>
            </div>
            <div class="item-1-contact"></div>
            <div class="item-2-contact"></div>
            <div class="contact-content">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
            </div>
                <div class="row">
                <div class="col-md-6">
                    <div class="name">
                        <div class="form-group">
                            <label for="email">Name:</label>
                            <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="email">
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="message" style="font-size: 20px;margin-top: 40px">
                        <div class="form-group">
                            <label for="comment">Message:</label>
                            <textarea class="form-control" rows="5" id="comment"></textarea>
                        </div>
                        <div class="send" style="text-align: right;">
                            <button type="button" class="btn btn-default" style="background: #00a5ff;color:#ffffff">SEND</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-12"><p style="text-align: left">ALL RIGHTS RESERVED. COPYRIGHT © 2015 <span>THE CURSEBORN SAGA</span></p></div>
                <div class="col-md-4 col-sm-12 social">
                    <ul class="list-inline">
                        <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                        <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                        <li><a href="#"><i class="fa fa-dribbble" aria-hidden="true"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/slick.min.js"></script>
<script src="js/lightbox.js"></script>
<script src="js/parallax.min.js"></script>
<script src="js/main.js"></script>
<script src="js/main_2.js"></script>
<script src="js/scroll.js"></script>
<script src="js/para.js"></script>
<script src="js/filter.js"></script>
</body>
</html>